<footer class="app-footer">
<ul class="app-nav">
        <li class="app-search">
          <span style="color: #8a8989; font-size: 12px;"> Copyright 2018 &copy;  All Rights Reserved &nbsp;&nbsp;&nbsp;&nbsp; |</span>
        </li>
        
        <li class="app-search">
          <span style="color: #8a8989; font-size: 12px"><strong style="color: #26a69a">Developed by</strong> <a href="https://www.google.com/" class="" style="color: #8a8989;" target="_blank"> Test IT Solution Private Limited </a></span>
        </li>
</ul>
</footer>
  <!-- Essential javascripts for application to work-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
  <!-- The javascript plugin to display page loading on top-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/pace.min.js"></script>
  <!-- Data table plugin-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap3-typeahead.min.js"></script>
    
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jszip.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/pdfmake.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/vfs_fonts.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/buttons.print.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/buttons.colVis.min.js"></script>
    
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/bootstrap-notify.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/sweetalert.min.js"></script>
  <!-- Plugin for table to json -->
     <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery.tabletojson.min.js"></script>
  <!-- Page specific javascripts--> 
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/main.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/common.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jQuery.print.js"></script>    
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/validation.js"></script>
    <!-- for date picker -->
    

   