<table id="role" class="table table-hover" style="width:100%">
        <thead>
            <tr>
                <th>Sl. No.</th>
                <th>Name</th>
                <th>
                <div class="animated-checkbox">
              	<label>
                <input onclick="checkAllCheckbox($(this));" type="checkbox" ><span class="label-text">Delete All</span>
              	</label>
            	</div>
            	</th>
            </tr>
        </thead>
    
       
    </table>