	<div class="row" style="margin:15px; width: 100%">
				<table class="table table-hover" style="">
					<tbody>
						<tr>
							<th class="table_head">Group Name :</th>
							<td><?php echo $group_details[0]['Group_name'];?></td>
							<th class="table_head">Group Address :</th>
							<td><?php echo $group_details[0]['Address'];?></td>
							<th class="table_head">Max. Member Allow:</th>
							<td><?php echo $group_details[0]['max_member_count'];?></td>
						</tr>
						<tr>
							<th class="table_head">Group Code: </th>
							<td><?php echo $group_details[0]['Group_code'];?></td>
							<th class="table_head">Group Area</th>
							<td><?php echo $group_details[0]['Area'];?></td>
							<th class="table_head">Total Added</th>
							<td><?php echo $group_details[0]['customer_count'];?></td>
						</tr>
						
					</tbody>
				</table>

			

				
			</div>