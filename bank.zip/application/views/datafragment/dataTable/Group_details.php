	<div class="row" style="margin:15px; width: 100%">
		<div class="col-6">
			<b>Group Name : </b><?php echo $group_details[0]['Group_name'];?><br>
			<b><address>Group Code:</b><?php echo $group_details[0]['Group_code'];?><br>
			<b>Group Address :</b><?php echo $group_details[0]['Address'];?><br>
			<b>Group Area : </b><?php echo $group_details[0]['Area'];?><br>
		</div>
		<div class="col-6">
			<b>Max. Member Allow : </b><?php echo $group_details[0]['max_member_count'];?><br>
			<b>Total Added : </b><?php echo $group_details[0]['customer_count'];?><br>
		</div>
	</div>